
package main

import (
    "log"
    "my-go-project/internal/kubernetes"
    "my-go-project/internal/tui"
    "github.com/rivo/tview"
    "k8s.io/client-go/kubernetes"
    "k8s.io/client-go/tools/clientcmd"
    "os"
)

func main() {
    // Load Kubernetes config
    kubeconfig := "/path/to/your/kubeconfig" // Set the correct path to kubeconfig file
    config, err := clientcmd.BuildConfigFromFlags("", kubeconfig)
    if err != nil {
        log.Fatalf("Error building kubeconfig: %s", err)
    }

    // Create Kubernetes clientset
    clientset, err := kubernetes.NewForConfig(config)
    if err != nil {
        log.Fatalf("Error creating Kubernetes client: %s", err)
    }

    // Create a new tview application
    app := tview.NewApplication()

    // Render the TUI sections
    renderTUI(app, clientset)

    // Run the application
    if err := app.Run(); err != nil {
        log.Fatalf("Error running the application: %v", err)
    }
}

// renderTUI will render the dashboard and allow dynamic section changes
func renderTUI(app *tview.Application, clientset *kubernetes.Clientset) {
    // Set the initial layout (you can switch views later)
    layout := tview.NewFlex().
        AddItem(tview.NewTextView().SetText("Welcome to k8s-viewer!").SetTextAlign(tview.AlignCenter), 0, 1, false).
        AddItem(tview.NewButton("Service Info").SetSelectedFunc(func() {
            tui.RenderService(clientset, app, "default", "py-kannel-service") // Render service info
        }), 0, 1, false).
        AddItem(tview.NewButton("Pod Info").SetSelectedFunc(func() {
            tui.RenderPod(clientset, app, "default", "py-kannel-pod") // Render pod info
        }), 0, 1, false)

    app.SetRoot(layout, true)
}
