
package tui

import (
    "fmt"
    "my-go-project/internal/kubernetes"
)

// RenderDashboard renders the deployment, service, and pod monitoring sections of the dashboard
func RenderDashboard() {
    fmt.Println("|------------------------------ k8s-viewer-rules ------------------------------|")
    fmt.Println("|---------------------------- Label: app-py-kannel -----------------------------|")
    fmt.Println("|-------------------------------------------------------------------------------|")
    fmt.Println("| Deployment Details     | Service Details      | Pod Monitoring                |")
    fmt.Println("|------------------------|----------------------|------------------------------|")
    fmt.Println("| Name: py-kannel        | Name: py-kannel-service | Endpoint: py-kannel-pod      |")
    fmt.Println("| Version: v1.2.3        | Endpoints: 192.100    | Status: Running              |")
    fmt.Println("| Status: Running        | 192.160.1.1:26881    | CPU Usage: 80%               |")
    fmt.Println("| Replicas: 3/3          | Status: Healthy 1    | Memory Usage: 50MB           |")
    fmt.Println("|------------------------|----------------------|------------------------------|")
}
