
package kubernetes

import (
    "context"
    "fmt"
    "github.com/rivo/tview"
    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    "k8s.io/client-go/kubernetes"
)

// GetPodInfo fetches pod details from the Kubernetes cluster
func GetPodInfo(clientset *kubernetes.Clientset, namespace, podName string) (string, string) {
    pod, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), podName, metav1.GetOptions{})
    if err != nil {
        return "", fmt.Sprintf("Error retrieving pod: %v", err)
    }
    return pod.Name, fmt.Sprintf("Status: %s", pod.Status.Phase)
}

// RenderPod renders the pod details in the TUI
func RenderPod(clientset *kubernetes.Clientset, app *tview.Application, namespace, podName string) {
    name, status := GetPodInfo(clientset, namespace, podName)

    // Create a new flex layout for pod information
    flex := tview.NewFlex().
        AddItem(tview.NewTextView().SetText("Pod Monitoring").SetTextAlign(tview.AlignCenter), 1, 0, false).
        AddItem(tview.NewTextView().SetText(fmt.Sprintf("Name: %s", name)), 1, 0, false).
        AddItem(tview.NewTextView().SetText(status), 1, 0, false)

    app.SetRoot(flex, true)
}
