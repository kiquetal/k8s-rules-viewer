
package main

import (
    "log"
    "my-go-project/internal/kubernetes"
    "github.com/rivo/tview"
    "k8s.io/client-go/kubernetes"
    "k8s.io/client-go/tools/clientcmd"
    "os"
)

func main() {
    // Load Kubernetes config
    kubeconfig := "/path/to/your/kubeconfig" // Set the correct path to kubeconfig file
    config, err := clientcmd.BuildConfigFromFlags("", kubeconfig)
    if err != nil {
        log.Fatalf("Error building kubeconfig: %s", err)
    }

    // Create Kubernetes clientset
    clientset, err := kubernetes.NewForConfig(config)
    if err != nil {
        log.Fatalf("Error creating Kubernetes client: %s", err)
    }

    // Create a new tview application
    app := tview.NewApplication()

    // Render Service and Pod sections
    kubernetes.RenderService(clientset, app, "default", "py-kannel-service")
    kubernetes.RenderPod(clientset, app, "default", "py-kannel-pod")

    // Run the application
    if err := app.Run(); err != nil {
        log.Fatalf("Error running the application: %v", err)
    }
}
