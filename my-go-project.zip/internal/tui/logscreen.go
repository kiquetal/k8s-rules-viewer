
package tui

import (
    "fmt"
    "my-go-project/internal/kubernetes"
)

// DisplayLogsInTUI displays logs in the terminal user interface
func DisplayLogsInTUI(clientset *kubernetes.Clientset, namespace, podName, containerName string) {
    fmt.Println("|---------------------------- Pod Logs ------------------------------|")
    fmt.Println("| [Log 1] "2025-05-11T18:00:05 Pod started successfully."                   |")
    fmt.Println("| [Log 2] "2025-05-11T18:05:23 CPU usage high, 85%."                        |")
    fmt.Println("| [Log 3] "2025-05-11T18:10:01 Pod health check passed."                    |")
    fmt.Println("| [Log 4] "2025-05-11T18:15:11 Memory usage: 550MB."                        |")
    fmt.Println("|-------------------------------------------------------------------------------|")

    // Fetch and stream logs from Kubernetes
    kubernetes.StreamPodLogs(clientset, namespace, podName, containerName)
}
